namespace CALCULTOR
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string ctotal;
        double n1, n2;
        string option;
        double result;



        private void button4_Click(object sender, EventArgs e)
        {
            // clear button

            textBox1.Text = string.Empty;

        }

        // number display KLsnOADNAPOD

        private void button17_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + button17.Text;

        }

        private void button13_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + button13.Text;
        }


        private void btn1_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + btn1.Text;
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + btn2.Text;
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + btn3.Text;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + button5.Text;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + button6.Text;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + button7.Text;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + button1.Text;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + button2.Text;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + button3.Text;
        }

        // operators

        private void button16_Click(object sender, EventArgs e)
        {
            option = "+";
            n1 = double.Parse(textBox1.Text);
            textBox1.Clear();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            option = "-";
            n1 = double.Parse(textBox1.Text);
            textBox1.Clear();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            option = "x";
            n1 = double.Parse(textBox1.Text);
            textBox1.Clear();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            option = "/";
            n1 = double.Parse(textBox1.Text);
            textBox1.Clear();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            // equal button

            n2 = double.Parse(textBox1.Text);

            if (option.Equals("+"))
                result = n1 + n2;

            n2 = double.Parse(textBox1.Text);

            if (option.Equals("-"))
                result = n1 - n2;

            n2 = double.Parse(textBox1.Text);

            if (option.Equals("x"))
                result = n1 * n2;

            n2 = double.Parse(textBox1.Text);

            if (option.Equals("/"))
                result = n1 / n2;

            textBox1.Text = result + "";


        }
         
    }
}
